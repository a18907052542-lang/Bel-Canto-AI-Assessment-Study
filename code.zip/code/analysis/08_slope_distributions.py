"""
08_slope_distributions.py

Produces Figure 9 — Kernel density and quartile visualization of individual
AAI slopes between conditions. Combined violin + box plot.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
import seaborn as sns

from analysis._utils import (build_aai_wide, compute_individual_slopes,
                             apply_style, get_logger)
from config import reference_values as pt


def main():
    log = get_logger("08_slopes")
    log.info("=" * 70)
    log.info("Module 08 — Slope Distributions (Figure 9)")

    wide = build_aai_wide()
    slopes = compute_individual_slopes(wide)

    apply_style()
    fig, axes = plt.subplots(1, 2, figsize=(14, 6),
                              gridspec_kw={"width_ratios": [1, 1.3]})

    # ---- Panel A: violin + box ----
    ax = axes[0]
    palette = {"A": pt.COLORS["condA"], "B": pt.COLORS["condB"]}

    parts = ax.violinplot(
        [slopes.loc[slopes["Condition"]=="A", "AAI_slope"].values,
         slopes.loc[slopes["Condition"]=="B", "AAI_slope"].values],
        positions=[0, 1], showmeans=False, showmedians=False, showextrema=False,
        widths=0.7)
    for pc, color in zip(parts["bodies"], [palette["A"], palette["B"]]):
        pc.set_facecolor(color); pc.set_alpha(0.55); pc.set_edgecolor("black"); pc.set_linewidth(0.8)

    # Overlay box plots
    for i, cond in enumerate(["A", "B"]):
        data = slopes.loc[slopes["Condition"] == cond, "AAI_slope"].values
        bp = ax.boxplot(data, positions=[i], widths=0.15, patch_artist=True,
                        boxprops=dict(facecolor="white", color="black", linewidth=1.2),
                        medianprops=dict(color=palette[cond], linewidth=2.5),
                        whiskerprops=dict(color="black", linewidth=1),
                        capprops=dict(color="black", linewidth=1),
                        flierprops=dict(marker="o", markersize=4,
                                        markerfacecolor=palette[cond], markeredgecolor="black", alpha=0.4))

    ax.axhline(0, ls="--", color="#606060", lw=1, alpha=0.6)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Condition A\n(transparent)", "Condition B\n(opaque)"], fontsize=10)
    ax.set_ylabel("Individual AAI Linear Slope (β per wave)", fontsize=11)
    ax.set_title("Panel A: Violin + Box of Individual Slopes",
                 fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)

    # Annotate mean slopes
    for i, cond in enumerate(["A", "B"]):
        m = slopes.loc[slopes["Condition"] == cond, "AAI_slope"].mean()
        sd = slopes.loc[slopes["Condition"] == cond, "AAI_slope"].std(ddof=1)
        ax.text(i, ax.get_ylim()[1]*0.92, f"M = {m:+.3f}\nSD = {sd:.3f}",
                ha="center", fontsize=9.5, color=palette[cond], fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.4", fc="white", ec=palette[cond]))

    # ---- Panel B: kernel densities ----
    ax = axes[1]
    for cond in ["A", "B"]:
        data = slopes.loc[slopes["Condition"] == cond, "AAI_slope"].values
        kde = stats.gaussian_kde(data)
        x = np.linspace(data.min() - 0.1, data.max() + 0.1, 300)
        y = kde(x)
        ax.fill_between(x, 0, y, color=palette[cond], alpha=0.35, label=f"Condition {cond}")
        ax.plot(x, y, color=palette[cond], lw=2.2)

    ax.axvline(0, ls="--", color="#606060", lw=1, alpha=0.7)
    ax.set_xlabel("Individual AAI Linear Slope (β per wave)", fontsize=11)
    ax.set_ylabel("Density", fontsize=11)
    ax.set_title("Panel B: Kernel Density Distributions",
                 fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)
    ax.legend(loc="upper right", frameon=True, fontsize=11)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)

    fig.suptitle("Figure 9. Kernel Density and Quartile Visualization of Individual AAI Slopes",
                 fontsize=13.5, fontweight="bold", color=pt.COLORS["condA"], y=1.02)
    fig.tight_layout()
    fig.savefig(pt.FIGURES_DIR / "Fig09_SlopeDistributions.png",
                dpi=pt.FIGURE_STYLE["dpi"], bbox_inches="tight", facecolor="white")
    plt.close(fig)

    log.info(f"A slopes: n={sum(slopes['Condition']=='A')}, "
             f"M={slopes.loc[slopes['Condition']=='A','AAI_slope'].mean():+.3f}, "
             f"SD={slopes.loc[slopes['Condition']=='A','AAI_slope'].std(ddof=1):.3f}")
    log.info(f"B slopes: n={sum(slopes['Condition']=='B')}, "
             f"M={slopes.loc[slopes['Condition']=='B','AAI_slope'].mean():+.3f}, "
             f"SD={slopes.loc[slopes['Condition']=='B','AAI_slope'].std(ddof=1):.3f}")
    log.info("Saved: figures/Fig09_SlopeDistributions.png")
    log.info("Module 08 complete.\n")


if __name__ == "__main__":
    main()
