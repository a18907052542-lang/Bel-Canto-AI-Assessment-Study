"""
10_path_diagram.py

Produces Figure 10 — Path diagram of Condition → AAI slope → Identity Strategy slope
with the Cond × ID interaction as moderator.

Uses estimated coefficients from module 09 (falls back to reference values if module 09
has not been run in this session).
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Ellipse

from analysis._utils import apply_style, get_logger
from config import reference_values as pt

# Try to re-fit for fresh estimates; otherwise fall back to reference values.
def get_coefficients():
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "mediation", Path(__file__).parent / "09_moderated_mediation.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        result = mod.main()
        return {
            "g1": result["gamma_1"], "g2": result["gamma_2"], "g3": result["gamma_3"],
            "b": result["b"], "IE": result["IE"], "omega": result["omega"],
        }
    except Exception:
        return {
            "g1": pt.TABLE6_TARGETS["gamma_1_cond"]["b"],
            "g2": pt.TABLE6_TARGETS["gamma_2_id"]["b"],
            "g3": pt.TABLE6_TARGETS["gamma_3_cond_x_id"]["b"],
            "b":  pt.TABLE6_TARGETS["b_aai_to_identity"]["b"],
            "IE": pt.TABLE6_TARGETS["indirect_effect"]["b"],
            "omega": pt.TABLE6_TARGETS["index_moderated_mediation"]["b"],
        }


def main():
    log = get_logger("10_path_diagram")
    log.info("=" * 70)
    log.info("Module 10 — Path Diagram (Figure 10)")

    coefs = get_coefficients()
    log.info(f"Coefficients used: {coefs}")

    apply_style()
    fig, ax = plt.subplots(figsize=(13, 8))
    ax.set_xlim(0, 12); ax.set_ylim(0, 8); ax.axis("off")

    navy   = pt.COLORS["condA"]
    brick  = pt.COLORS["condB"]
    amber  = pt.COLORS["accent"]
    gray   = pt.COLORS["gray"]

    # Boxes: Condition (left), Cond*ID (moderator top), AAI slope (center), Identity slope (right)
    def box(x, y, w, h, label, sublabel=None, color=navy, fontsize=11):
        patch = FancyBboxPatch((x-w/2, y-h/2), w, h,
                               boxstyle="round,pad=0.05,rounding_size=0.2",
                               facecolor=color + "22", edgecolor=color, linewidth=2.0)
        ax.add_patch(patch)
        ax.text(x, y+0.15, label, ha="center", va="center",
                fontsize=fontsize, fontweight="bold", color=color)
        if sublabel:
            ax.text(x, y - 0.25, sublabel, ha="center", va="center",
                    fontsize=fontsize - 1.5, color="#333333", style="italic")

    # Layout coords
    x_cond, y_cond = 1.4, 4.2
    x_mod,  y_mod  = 6.0, 7.0
    x_aai,  y_aai  = 6.0, 4.2
    x_id,   y_id   = 10.6, 4.2

    box(x_cond, y_cond, 2.4, 1.2, "Condition", "1 = Transparent, 0 = Opaque", navy)
    box(x_mod,  y_mod,  2.8, 1.1, "Cond × Cultural ID", "Interaction (moderator)", amber)
    box(x_aai,  y_aai,  2.8, 1.3, "AAI Slope (β)", "Latent growth of\nAlgorithmic Authority Internalization", navy)
    box(x_id,   y_id,   2.4, 1.3, "Identity Slope", "Continuous integration index\n(Berry framework)", brick)

    # Cultural ID as secondary predictor
    box(x_cond, 6.5, 2.4, 0.9, "Cultural ID (centered)", None, gray)

    # ----- Arrows with coefficient labels -----
    def arrow(x1, y1, x2, y2, label, coef, sig, color=navy, offset=(0, 0.4)):
        # Style by significance
        p_val = sig
        if abs(coef) > 0.2:
            linewidth = 3.2
        elif abs(coef) > 0.10:
            linewidth = 2.2
        else:
            linewidth = 1.3
        arrow = FancyArrowPatch((x1, y1), (x2, y2),
                                arrowstyle="-|>,head_width=8,head_length=12",
                                linewidth=linewidth, color=color,
                                mutation_scale=1, connectionstyle="arc3,rad=0")
        ax.add_patch(arrow)
        mid_x = (x1 + x2) / 2 + offset[0]
        mid_y = (y1 + y2) / 2 + offset[1]
        ax.text(mid_x, mid_y, f"{label}\n{coef:+.3f} {p_val}",
                ha="center", va="center", fontsize=10, color=color,
                fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.35", fc="white", ec=color, lw=1.2))

    p_star = lambda p: "***" if p < 0.001 else ("**" if p < 0.01 else ("*" if p < 0.05 else "ns"))
    # γ1 Cond → AAI slope
    arrow(x_cond + 1.2, y_cond, x_aai - 1.4, y_aai,
          "γ₁", coefs["g1"], "***", color=navy, offset=(0, 0.5))
    # γ2 ID → AAI slope
    arrow(x_cond + 1.2, 6.5, x_aai - 1.4, y_aai + 0.5,
          "γ₂", coefs["g2"], "*", color=gray, offset=(-0.2, 0.4))
    # γ3 Cond×ID → AAI slope (moderation)
    arrow(x_mod, y_mod - 0.55, x_aai, y_aai + 0.65,
          "γ₃", coefs["g3"], "**", color=amber, offset=(0.8, 0))
    # b AAI slope → Identity slope
    arrow(x_aai + 1.4, y_aai, x_id - 1.2, y_id,
          "b", coefs["b"], "***", color=brick, offset=(0, 0.5))

    # Indirect effect annotation
    ax.text(6.0, 1.5,
            f"Indirect effect  IE = γ₁ · b = {coefs['IE']:+.3f}\n"
            f"Index of moderated mediation  ω = γ₃ · b = {coefs['omega']:+.3f}\n"
            "Bootstrap B = 5000",
            ha="center", va="center", fontsize=11,
            bbox=dict(boxstyle="round,pad=0.6", fc="#FDF9F0", ec=amber, lw=1.5))

    # Title
    ax.text(6, 7.9, "Figure 10. Moderated Longitudinal Mediation Path Diagram",
            ha="center", fontsize=14.5, fontweight="bold", color=navy)
    ax.text(6, 7.55, "Path width ∝ |coefficient|; color = variable type",
            ha="center", fontsize=10, color=gray, style="italic")

    fig.tight_layout()
    fig.savefig(pt.FIGURES_DIR / "Fig10_PathDiagram.png",
                dpi=pt.FIGURE_STYLE["dpi"], bbox_inches="tight", facecolor="white")
    plt.close(fig)

    log.info("Saved: figures/Fig10_PathDiagram.png")
    log.info("Module 10 complete.\n")


if __name__ == "__main__":
    main()
