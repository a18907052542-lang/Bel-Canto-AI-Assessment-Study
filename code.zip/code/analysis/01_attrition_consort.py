"""
01_attrition_consort.py

Produces Figure 7 (CONSORT-style participant flow across four waves).
Reads: participant master. Outputs: figures/Fig07_CONSORT.png, tables/attrition_summary.csv
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from scipy import stats

from analysis._utils import (load_participant_master, load_all_aai_waves,
                             apply_style, get_logger, compare_to_reference, print_comparison)
from config import reference_values as pt


def compute_empirical_attrition():
    """Compute wave-by-wave counts from the participant master + AAI wave files."""
    master = load_participant_master()
    waves  = load_all_aai_waves()

    counts = {"A": {"recruited": 0, "T1": 0, "T2": 0, "T3": 0, "T4": 0},
              "B": {"recruited": 0, "T1": 0, "T2": 0, "T3": 0, "T4": 0}}

    for c in ("A", "B"):
        counts[c]["recruited"] = int((master["Condition"] == c).sum())
        for w in range(1, 5):
            df_w = waves[w]
            counts[c][f"T{w}"] = int((df_w["Condition"] == c).sum())
    return counts


def test_dropout_homogeneity(counts):
    """chi-square test comparing dropouts between conditions from recruitment to T4."""
    a_drop = counts["A"]["recruited"] - counts["A"]["T4"]
    b_drop = counts["B"]["recruited"] - counts["B"]["T4"]
    a_kept = counts["A"]["T4"]
    b_kept = counts["B"]["T4"]
    table  = np.array([[a_drop, a_kept], [b_drop, b_kept]])
    chi2, p, _, _ = stats.chi2_contingency(table)
    return chi2, p


def make_consort_figure(counts, out_path):
    apply_style()
    fig, ax = plt.subplots(figsize=(11, 9))
    ax.set_xlim(0, 10); ax.set_ylim(0, 12); ax.axis("off")

    navy = pt.COLORS["condA"]; brick = pt.COLORS["condB"]; gray = pt.COLORS["gray"]

    # ------- Header
    ax.text(5, 11.5, "Figure 7. Participant Flow Across Four Waves (CONSORT-style)",
            ha="center", fontsize=14, fontweight="bold", color=navy)
    ax.text(5, 11.0, "N recruited = 440;  N final = 358 (attrition 18.6%)",
            ha="center", fontsize=10, color=gray, style="italic")

    def box(x, y, w, h, text, color, fc=None, fontsize=10, weight="normal"):
        if fc is None: fc = color + "22"    # translucent fill
        patch = FancyBboxPatch((x-w/2, y-h/2), w, h,
                               boxstyle="round,pad=0.05,rounding_size=0.15",
                               facecolor=fc, edgecolor=color, linewidth=1.4)
        ax.add_patch(patch)
        ax.text(x, y, text, ha="center", va="center", fontsize=fontsize,
                color="#111111", weight=weight, wrap=True)

    def arrow(x1, y1, x2, y2, color="#555555"):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2),
                                     arrowstyle="-|>,head_width=6,head_length=8",
                                     linewidth=1.2, color=color, mutation_scale=1))

    # ------- Enrollment
    box(5, 10.2, 5.5, 0.7,
        f"Assessed for eligibility (N = 512)",
        gray, fontsize=10.5, weight="bold")

    # Excluded
    box(8.6, 9.3, 3.0, 1.3,
        "Excluded (n = 72):\n"
        "  •  did not meet criteria (41)\n"
        "  •  voluntary withdrawal (26)\n"
        "  •  other (5)",
        "#8B3A3A", fc="#F9E6E6", fontsize=8.6)

    arrow(5, 9.85, 5, 9.2)
    arrow(6.4, 10.2, 7.1, 9.7, color="#8B3A3A")

    # Recruited & assigned
    box(5, 8.85, 5.5, 0.6,
        f"Enrolled and quasi-randomized to condition (N = 440)",
        navy, fontsize=10.5, weight="bold")

    # Split
    arrow(5, 8.55, 2.3, 7.7)   # to A
    arrow(5, 8.55, 7.7, 7.7)   # to B

    # ------- Two columns
    x_A = 2.3
    x_B = 7.7

    box(x_A, 7.4, 3.9, 0.55,
        f"Condition A (transparent standard)\nn = {counts['A']['recruited']}",
        navy, fontsize=10, weight="bold")
    box(x_B, 7.4, 3.9, 0.55,
        f"Condition B (opaque standard)\nn = {counts['B']['recruited']}",
        brick, fontsize=10, weight="bold")

    # Rows for T1..T4
    waves = ["T1 (Week 2)", "T2 (Week 7)", "T3 (Week 12)", "T4 (Week 17)"]
    y_positions = [6.4, 5.2, 4.0, 2.8]
    prev_A = counts["A"]["recruited"]; prev_B = counts["B"]["recruited"]

    for i, (label, y) in enumerate(zip(waves, y_positions)):
        wkey = f"T{i+1}"
        nA = counts["A"][wkey]; nB = counts["B"][wkey]
        dropA = prev_A - nA;    dropB = prev_B - nB

        box(x_A, y, 3.9, 0.55, f"{label}: n = {nA}   (lost {dropA})",
            navy, fontsize=9.5)
        box(x_B, y, 3.9, 0.55, f"{label}: n = {nB}   (lost {dropB})",
            brick, fontsize=9.5)

        # Vertical arrows down to next
        top_prev_A = 7.4 - 0.275 if i == 0 else y_positions[i-1] - 0.275
        arrow(x_A, top_prev_A, x_A, y + 0.275, navy)
        top_prev_B = 7.4 - 0.275 if i == 0 else y_positions[i-1] - 0.275
        arrow(x_B, top_prev_B, x_B, y + 0.275, brick)

        prev_A = nA; prev_B = nB

    # ------- Final analytic samples
    box(x_A, 1.9, 3.9, 0.55,
        f"Analyzed n = {counts['A']['T4']}",
        navy, fc=navy + "44", fontsize=10, weight="bold")
    box(x_B, 1.9, 3.9, 0.55,
        f"Analyzed n = {counts['B']['T4']}",
        brick, fc=brick + "44", fontsize=10, weight="bold")

    arrow(x_A, 2.525, x_A, 2.175, navy)
    arrow(x_B, 2.525, x_B, 2.175, brick)

    # ------- Homogeneity of dropout
    chi2, p = test_dropout_homogeneity(counts)
    box(5, 0.9, 6.5, 0.6,
        f"Dropout homogeneity between conditions: χ²(1) = {chi2:.2f}, p = {p:.3f}\n"
        f"(prior work reports χ²(1) = 0.54, p = .463)",
        gray, fc="#F2F2F2", fontsize=9.5, weight="normal")

    fig.savefig(out_path, dpi=pt.FIGURE_STYLE["dpi"], bbox_inches="tight",
                facecolor="white")
    plt.close(fig)


def main():
    log = get_logger("01_attrition")
    log.info("=" * 70)
    log.info("Module 01 — Attrition & CONSORT Figure")

    counts = compute_empirical_attrition()

    # Compare to reference values
    comps = []
    for cond in ("A", "B"):
        for wave in ("recruited", "T1", "T2", "T3", "T4"):
            reference_val = (pt.CONSORT_A if cond == "A" else pt.CONSORT_B)[wave]
            comps.append(compare_to_reference(
                f"{cond} {wave}", counts[cond][wave], reference_val, tol_key="percentage"))

    chi2, p = test_dropout_homogeneity(counts)
    comps.append(compare_to_reference("Dropout χ²", chi2, pt.DROPOUT_CHI2["chi2"], "chi2"))
    comps.append(compare_to_reference("Dropout p",  p,    pt.DROPOUT_CHI2["p"],    "pvalue"))
    print_comparison(comps, "Empirical CONSORT counts vs reference Figure 7")

    # Save table
    tbl = []
    for cond in ("A", "B"):
        for wave in ("recruited", "T1", "T2", "T3", "T4"):
            tbl.append({"condition": cond, "wave": wave,
                        "empirical_n": counts[cond][wave],
                        "reference_n": (pt.CONSORT_A if cond == "A" else pt.CONSORT_B)[wave]})
    df_out = pd.DataFrame(tbl)
    df_out.to_csv(pt.TABLES_DIR / "01_attrition_summary.csv", index=False)
    log.info(f"Saved: tables/01_attrition_summary.csv")

    # Figure
    fig_path = pt.FIGURES_DIR / "Fig07_CONSORT.png"
    make_consort_figure(counts, fig_path)
    log.info(f"Saved: figures/Fig07_CONSORT.png")

    log.info("Module 01 complete.\n")
    return {"counts": counts, "chi2": chi2, "p_dropout": p}


if __name__ == "__main__":
    main()
