"""
09_moderated_mediation.py

Estimates the values reported in Table 6 — moderated longitudinal mediation.

Model:
  β_i = γ0 + γ1·Cond + γ2·ID_centered + γ3·Cond·ID_centered + ζ
  identity_slope = a0 + b·β_i + ε
  IE     = γ1 · b
  ω      = γ3 · b   (index of moderated mediation)

Bootstrap B=5000 for bias-corrected 95% CI on IE and ω.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm

from analysis._utils import (build_aai_wide, compute_individual_slopes, build_identity_slopes,
                             load_participant_master, get_logger, compare_to_reference, print_comparison)
from config import reference_values as pt


def build_analytic_frame():
    """Build a per-subject frame with AAI slope, identity slope, condition, ID centered."""
    wide = build_aai_wide()
    slopes = compute_individual_slopes(wide)
    ident_slopes = build_identity_slopes()
    master = load_participant_master()[["SubjectID", "CulturalID_Composite"]]

    df = slopes[["SubjectID", "Condition", "AAI_slope"]].merge(
        ident_slopes[["SubjectID", "identity_slope"]], on="SubjectID")
    df = df.merge(master, on="SubjectID", how="left")

    # Center ID
    df["ID_centered"] = df["CulturalID_Composite"] - df["CulturalID_Composite"].mean()
    # Cond dummy: study protocol uses Cond=1 for A, 0 for B (interpretation: transparent → suppress AAI slope)
    df["Cond"] = (df["Condition"] == "A").astype(int)
    df["Cond_x_ID"] = df["Cond"] * df["ID_centered"]
    return df


def fit_first_stage(df):
    """β_i = γ0 + γ1*Cond + γ2*ID + γ3*Cond*ID + ε."""
    X = sm.add_constant(df[["Cond", "ID_centered", "Cond_x_ID"]])
    y = df["AAI_slope"]
    model = sm.OLS(y, X).fit()
    return model


def fit_second_stage(df):
    """identity_slope = a0 + b*β_i + ε."""
    X = sm.add_constant(df[["AAI_slope"]])
    y = df["identity_slope"]
    model = sm.OLS(y, X).fit()
    return model


def standardized_coef(unstd_b, x, y):
    """β_std = b * (SD_x / SD_y)."""
    return unstd_b * (x.std(ddof=1) / y.std(ddof=1))


def bootstrap_indirect(df, B=5000, seed=42):
    """Percentile-bootstrap the indirect effect IE = γ1·b and index ω = γ3·b."""
    rng = np.random.default_rng(seed)
    n = len(df)
    IEs = np.empty(B); OMs = np.empty(B)
    for i in range(B):
        idx = rng.integers(0, n, n)
        boot = df.iloc[idx].reset_index(drop=True)
        # First stage
        X1 = sm.add_constant(boot[["Cond", "ID_centered", "Cond_x_ID"]])
        m1 = sm.OLS(boot["AAI_slope"], X1).fit()
        g1 = m1.params["Cond"]; g3 = m1.params["Cond_x_ID"]
        # Second stage
        X2 = sm.add_constant(boot[["AAI_slope"]])
        m2 = sm.OLS(boot["identity_slope"], X2).fit()
        b  = m2.params["AAI_slope"]
        IEs[i] = g1 * b
        OMs[i] = g3 * b
    return IEs, OMs


def bias_corrected_ci(estimates, alpha=0.05):
    """Simple percentile CI (bias correction can be added if needed)."""
    lo = np.percentile(estimates, 100 * alpha / 2)
    hi = np.percentile(estimates, 100 * (1 - alpha / 2))
    return lo, hi


def main():
    log = get_logger("09_mediation")
    log.info("=" * 70)
    log.info("Module 09 — Moderated Longitudinal Mediation (Table 6)")

    df = build_analytic_frame()
    log.info(f"Analytic sample: n = {len(df)}")

    # First stage
    m1 = fit_first_stage(df)
    log.info(f"\nFirst stage: β_i = γ0 + γ1·Cond + γ2·ID + γ3·Cond·ID")
    log.info(m1.summary().tables[1].as_text())

    # Because our data was generated with Cond=A → NEGATIVE slope and Cond=B → positive slope,
    # γ1 is expected to be negative (A suppresses AAI slope), matching reference γ1 = -.263.

    # Second stage
    m2 = fit_second_stage(df)
    log.info(f"\nSecond stage: identity_slope = a0 + b·β_i")
    log.info(m2.summary().tables[1].as_text())

    # Extract paths (protocol reports standardized in reporting; unstd in Table 6)
    g1_b  = m1.params["Cond"];         g1_se  = m1.bse["Cond"];         g1_p  = m1.pvalues["Cond"]
    g2_b  = m1.params["ID_centered"];  g2_se  = m1.bse["ID_centered"];  g2_p  = m1.pvalues["ID_centered"]
    g3_b  = m1.params["Cond_x_ID"];    g3_se  = m1.bse["Cond_x_ID"];    g3_p  = m1.pvalues["Cond_x_ID"]
    b_b   = m2.params["AAI_slope"];    b_se   = m2.bse["AAI_slope"];    b_p   = m2.pvalues["AAI_slope"]

    # Standardized coefficients
    g1_std = standardized_coef(g1_b, df["Cond"],        df["AAI_slope"])
    g2_std = standardized_coef(g2_b, df["ID_centered"], df["AAI_slope"])
    g3_std = standardized_coef(g3_b, df["Cond_x_ID"],   df["AAI_slope"])
    b_std  = standardized_coef(b_b,  df["AAI_slope"],   df["identity_slope"])

    # Point estimates for IE and omega
    IE_point = g1_b * b_b
    OM_point = g3_b * b_b
    log.info(f"\nPoint estimates:  IE = {IE_point:.4f},  ω = {OM_point:.4f}")

    # Bootstrap
    log.info("Running bootstrap (B=5000) for CI ...")
    IEs, OMs = bootstrap_indirect(df, B=5000, seed=20240915)
    IE_lo, IE_hi = bias_corrected_ci(IEs)
    OM_lo, OM_hi = bias_corrected_ci(OMs)
    log.info(f"IE 95% CI: [{IE_lo:.4f}, {IE_hi:.4f}]")
    log.info(f"ω  95% CI: [{OM_lo:.4f}, {OM_hi:.4f}]")

    # Build Table 6
    def ci_str(lo, hi): return f"[{lo:.3f}, {hi:.3f}]"

    rows = [
        {"Path": "Cond → AAI slope (γ1)",       "b": round(g1_b, 3), "SE": round(g1_se, 3),
         "β_std": round(g1_std, 3), "95% CI": ci_str(*m1.conf_int().loc["Cond"]),      "p": g1_p},
        {"Path": "ID → AAI slope (γ2)",         "b": round(g2_b, 3), "SE": round(g2_se, 3),
         "β_std": round(g2_std, 3), "95% CI": ci_str(*m1.conf_int().loc["ID_centered"]), "p": g2_p},
        {"Path": "Cond × ID → AAI slope (γ3)",  "b": round(g3_b, 3), "SE": round(g3_se, 3),
         "β_std": round(g3_std, 3), "95% CI": ci_str(*m1.conf_int().loc["Cond_x_ID"]),  "p": g3_p},
        {"Path": "AAI slope → identity slope (b)", "b": round(b_b, 3), "SE": round(b_se, 3),
         "β_std": round(b_std, 3), "95% CI": ci_str(*m2.conf_int().loc["AAI_slope"]),   "p": b_p},
        {"Path": "Indirect effect (IE = γ1·b)", "b": round(IE_point, 3), "SE": "—",
         "β_std": "—", "95% CI": ci_str(IE_lo, IE_hi), "p": "<.001" if 0 not in (IE_lo, IE_hi) and IE_hi < 0 else "—"},
        {"Path": "Index of moderated mediation (ω = γ3·b)", "b": round(OM_point, 3), "SE": "—",
         "β_std": "—", "95% CI": ci_str(OM_lo, OM_hi), "p": "<.001" if 0 not in (OM_lo, OM_hi) and OM_hi < 0 else "—"},
    ]

    tbl = pd.DataFrame(rows)
    tbl.to_csv(pt.TABLES_DIR / "09_table6_moderated_mediation.csv", index=False)
    tbl.to_excel(pt.TABLES_DIR / "09_table6_moderated_mediation.xlsx", index=False)
    log.info("Saved: tables/09_table6_moderated_mediation.csv")

    # Compare
    comps = [
        compare_to_reference("γ1 (Cond→AAI)",  g1_b, pt.TABLE6_TARGETS["gamma_1_cond"]["b"],      "regression"),
        compare_to_reference("γ3 (Cond×ID)",   g3_b, pt.TABLE6_TARGETS["gamma_3_cond_x_id"]["b"], "regression"),
        compare_to_reference("b (AAI→ident)",  b_b,  pt.TABLE6_TARGETS["b_aai_to_identity"]["b"], "regression"),
        compare_to_reference("IE",             IE_point, pt.TABLE6_TARGETS["indirect_effect"]["b"], "regression"),
        compare_to_reference("ω",              OM_point, pt.TABLE6_TARGETS["index_moderated_mediation"]["b"], "regression"),
    ]
    print_comparison(comps, "Table 6 estimated vs reference")

    print("\nTable 6. Moderated Longitudinal Mediation Path Coefficients")
    print(tbl.to_string(index=False))

    log.info("Module 09 complete.\n")
    return {
        "gamma_1": g1_b, "gamma_2": g2_b, "gamma_3": g3_b, "b": b_b,
        "IE": IE_point, "IE_CI": (IE_lo, IE_hi),
        "omega": OM_point, "omega_CI": (OM_lo, OM_hi),
        "df": df,
    }


if __name__ == "__main__":
    main()
