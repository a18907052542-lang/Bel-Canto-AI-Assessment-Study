"""
14_common_method_bias.py

Estimates values reported in Section 4.5 — Harman's single-factor test for common method bias.

Fits a single-factor EFA to all AAI items and reports the variance explained
by the first (single) factor. Paper reports 28.7% (< 40% threshold).
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd

from analysis._utils import (load_aai_wave, AAI_ALL_ITEMS,
                             get_logger, compare_to_reference, print_comparison)
from config import reference_values as pt


def harmans_single_factor(df, items):
    """
    Harman's single-factor test: extract one factor from a PCA on the item
    covariance matrix and return the % variance explained.
    """
    items_present = [it for it in items if it in df.columns]
    X = df[items_present].dropna().values.astype(float)

    # Standardize
    X = (X - X.mean(axis=0)) / X.std(axis=0, ddof=1)

    # Correlation matrix
    R = np.corrcoef(X, rowvar=False)
    eigvals = np.linalg.eigvalsh(R)
    eigvals = eigvals[::-1]                  # descending
    total   = eigvals.sum()
    first_factor_pct = 100 * eigvals[0] / total
    return first_factor_pct, eigvals


def main():
    log = get_logger("14_cmb")
    log.info("=" * 70)
    log.info("Module 14 — Common Method Bias (Harman's Single Factor)")

    # Use T1 items (most complete)
    df = load_aai_wave(1)
    pct, eigenvalues = harmans_single_factor(df, AAI_ALL_ITEMS)

    log.info(f"First factor variance explained: {pct:.1f}%")
    log.info(f"Paper reports: {pt.HARMAN_TARGETS['single_factor_variance_pct']}%")
    log.info(f"Threshold: {pt.HARMAN_TARGETS['threshold_pct']}% (below = CMB-free)")
    log.info(f"First 5 eigenvalues: {eigenvalues[:5].round(2)}")

    cmb_free = pct < pt.HARMAN_TARGETS["threshold_pct"]
    log.info(f"Conclusion: {'CMB-free ✓' if cmb_free else 'Warning: CMB may be present'}")

    comps = [compare_to_reference("First factor % variance",
                               pct, pt.HARMAN_TARGETS["single_factor_variance_pct"],
                               "percentage")]
    print_comparison(comps, "Harman's single factor test vs reference")

    tbl = pd.DataFrame([{
        "first_factor_variance_pct": round(pct, 1),
        "threshold_pct": pt.HARMAN_TARGETS["threshold_pct"],
        "cmb_free": cmb_free,
        "reference_first_factor_pct": pt.HARMAN_TARGETS["single_factor_variance_pct"],
        "reference_cmb_free": pt.HARMAN_TARGETS["cmb_free"],
        "n_items": len([it for it in AAI_ALL_ITEMS if it in df.columns]),
    }])
    tbl.to_csv(pt.TABLES_DIR / "14_common_method_bias.csv", index=False)
    log.info("Saved: tables/14_common_method_bias.csv")

    log.info("Module 14 complete.\n")


if __name__ == "__main__":
    main()
