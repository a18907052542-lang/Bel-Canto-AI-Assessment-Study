"""
07_trajectory_plots.py

Produces Figure 8 — Individual and Mean AAI Trajectories Across Four Waves.
Thin gray lines = individual trajectories.
Solid bands = mean ± 95% CI per condition.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

from analysis._utils import build_aai_wide, apply_style, get_logger
from config import reference_values as pt


def main():
    log = get_logger("07_trajectories")
    log.info("=" * 70)
    log.info("Module 07 — AAI Trajectories (Figure 8)")

    wide = build_aai_wide()
    apply_style()

    time_codes = np.array([0, 1, 2, 3])
    time_labels = ["T1 (Wk 2)", "T2 (Wk 7)", "T3 (Wk 12)", "T4 (Wk 17)"]
    wave_cols = ["AAI_T1", "AAI_T2", "AAI_T3", "AAI_T4"]

    fig, axes = plt.subplots(1, 2, figsize=(13, 6), sharey=True)
    conditions = ["A", "B"]
    colors = [pt.COLORS["condA"], pt.COLORS["condB"]]
    subtitles = ["Condition A — transparent standard", "Condition B — opaque standard"]

    for ax, cond, color, subtitle in zip(axes, conditions, colors, subtitles):
        sub = wide[wide["Condition"] == cond]
        n = len(sub)

        # Individual thin gray lines
        for _, row in sub.iterrows():
            y = row[wave_cols].values.astype(float)
            ax.plot(time_codes, y, color="#AAAAAA", alpha=0.18, lw=0.6)

        # Mean and 95% CI
        means = sub[wave_cols].mean().values
        sems  = sub[wave_cols].sem().values
        cis   = sems * stats.t.ppf(0.975, df=n-1)

        ax.fill_between(time_codes, means - cis, means + cis, color=color, alpha=0.25, zorder=3)
        ax.plot(time_codes, means, color=color, lw=2.5, marker="o", markersize=8,
                markeredgecolor="white", markeredgewidth=1.5, zorder=4,
                label=f"{cond} Mean (n={n})")

        ax.set_xticks(time_codes)
        ax.set_xticklabels(time_labels, fontsize=9)
        ax.set_title(subtitle, fontsize=12, fontweight="bold", color=color)
        ax.set_xlabel("Wave (time code)")
        ax.set_ylim(1.5, 5.0)
        ax.grid(True, alpha=0.35)
        ax.legend(loc="upper left", frameon=True, fontsize=10)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    axes[0].set_ylabel("AAI Composite Score (1–5)", fontsize=11)

    fig.suptitle("Figure 8. Individual and Mean AAI Trajectories Across Four Waves\n"
                 "(Thin gray lines = individuals; solid bands = mean ± 95% CI)",
                 fontsize=13, fontweight="bold", color=pt.COLORS["condA"], y=1.02)
    fig.tight_layout()
    fig.savefig(pt.FIGURES_DIR / "Fig08_Trajectories.png",
                dpi=pt.FIGURE_STYLE["dpi"], bbox_inches="tight", facecolor="white")
    plt.close(fig)

    log.info("Saved: figures/Fig08_Trajectories.png")
    log.info("Module 07 complete.\n")


if __name__ == "__main__":
    main()
