"""
12_thematic_joint_display.py

Estimates the values reported in Table 7 (mixed-methods joint display) and Figure 12 (heatmap of
qualitative theme frequencies with overlaid quantitative indicators).
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Rectangle

from analysis._utils import apply_style, get_logger
from config import reference_values as pt


THEME_NAMES = {
    "T1_Binding":            "Binding scores to self-worth",
    "T2_SourceAwareness":    "Source-awareness legitimacy restoration",
    "T3_AchievementParadox": "Standard attainment × integration paradox",
    "T4_TeacherAuthority":   "Repositioning of teacher authority",
    "T5_VocalPlurality":     "Imaginative space for vocal plurality",
}

TYPOLOGY_LABELS = {
    "HA_Assim": "High AAI + Assimilation",
    "HA_Int":   "High AAI + Integration",
    "LA_Int":   "Low AAI + Integration",
    "LA_Sep":   "Low AAI + Separation",
}

# Mean quantitative indicators per typology (for contour overlay)
QUANT_MARKERS = {
    "HA_Assim": {"AAI_slope":  0.32, "ID_slope": -0.12},
    "HA_Int":   {"AAI_slope":  0.24, "ID_slope":  0.09},
    "LA_Int":   {"AAI_slope": -0.05, "ID_slope":  0.16},
    "LA_Sep":   {"AAI_slope": -0.08, "ID_slope": -0.04},
}


def build_table7():
    rows = []
    for theme_key in THEME_NAMES:
        row = {"Qualitative theme": THEME_NAMES[theme_key]}
        for typ_key in TYPOLOGY_LABELS:
            label = pt.JOINT_DISPLAY_LABELS[theme_key][typ_key]
            count = pt.JOINT_DISPLAY_COUNTS[theme_key][typ_key]
            row[TYPOLOGY_LABELS[typ_key]] = f"{label} ({count})"
        rows.append(row)
    return pd.DataFrame(rows)


def build_heatmap_matrix():
    """Rows: themes; columns: typologies. Values = counts."""
    themes = list(THEME_NAMES.keys())
    typols = list(TYPOLOGY_LABELS.keys())
    mat = np.zeros((len(themes), len(typols)))
    for i, t in enumerate(themes):
        for j, u in enumerate(typols):
            mat[i, j] = pt.JOINT_DISPLAY_COUNTS[t][u]
    return mat, themes, typols


def plot_heatmap(out_path):
    apply_style()
    mat, themes, typols = build_heatmap_matrix()

    fig, ax = plt.subplots(figsize=(11, 6.5))
    cmap = mcolors.LinearSegmentedColormap.from_list(
        "navy_amber", ["#FDFDFD", "#F2E9D0", pt.COLORS["accent"], pt.COLORS["condA"]], N=256)

    im = ax.imshow(mat, aspect="auto", cmap=cmap, vmin=0, vmax=mat.max())

    # Annotate cells with count + AAI slope × ID slope
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            typ_key = list(TYPOLOGY_LABELS.keys())[j]
            count = int(mat[i, j])
            aai_s = QUANT_MARKERS[typ_key]["AAI_slope"]
            id_s  = QUANT_MARKERS[typ_key]["ID_slope"]
            color = "white" if mat[i, j] > mat.max() * 0.55 else "#111"
            ax.text(j, i, f"{count}",
                    ha="center", va="center", fontsize=15, fontweight="bold", color=color)

    # Overlay quantitative markers below each column header
    ax2 = ax.twiny()
    ax2.set_xlim(ax.get_xlim())
    ax2.set_xticks(range(len(typols)))
    quant_labels = [f"AAI β={QUANT_MARKERS[u]['AAI_slope']:+.2f}\nID β={QUANT_MARKERS[u]['ID_slope']:+.2f}"
                    for u in typols]
    ax2.set_xticklabels(quant_labels, fontsize=8.5, color="#333")
    ax2.tick_params(axis="x", pad=1)
    ax2.xaxis.set_ticks_position("top")

    # Main axis labels
    ax.set_xticks(range(len(typols)))
    ax.set_xticklabels([TYPOLOGY_LABELS[u] for u in typols], fontsize=10, rotation=15)
    ax.xaxis.set_ticks_position("bottom")
    ax.set_yticks(range(len(themes)))
    ax.set_yticklabels([THEME_NAMES[t] for t in themes], fontsize=10)

    ax.set_title("Figure 12. Heatmap of Theme Frequencies with Overlaid Quantitative Indicators",
                 fontsize=13, fontweight="bold", color=pt.COLORS["condA"], pad=45)

    cbar = plt.colorbar(im, ax=ax, shrink=0.85)
    cbar.set_label("Coded segment count", fontsize=10)

    fig.tight_layout()
    fig.savefig(out_path, dpi=pt.FIGURE_STYLE["dpi"], bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main():
    log = get_logger("12_joint_display")
    log.info("=" * 70)
    log.info("Module 12 — Thematic Joint Display (Table 7 + Figure 12)")

    tbl = build_table7()
    tbl.to_csv(pt.TABLES_DIR / "12_table7_joint_display.csv", index=False)
    tbl.to_excel(pt.TABLES_DIR / "12_table7_joint_display.xlsx", index=False)
    log.info("Saved: tables/12_table7_joint_display.csv")

    print("\nTable 7. Mixed Methods Joint Display Matrix")
    print(tbl.to_string(index=False))

    plot_heatmap(pt.FIGURES_DIR / "Fig12_JointDisplayHeatmap.png")
    log.info("Saved: figures/Fig12_JointDisplayHeatmap.png")
    log.info("Module 12 complete.\n")


if __name__ == "__main__":
    main()
