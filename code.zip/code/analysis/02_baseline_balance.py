"""
02_baseline_balance.py

Estimates the values reported in Table 2 — baseline demographic and characteristic balance between
Condition A and Condition B (t-tests for continuous variables, chi-square for
categorical variables).
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd
from scipy import stats

from analysis._utils import (load_participant_master, load_vocal_skill,
                             get_logger, compare_to_reference, print_comparison)
from config import reference_values as pt


def build_baseline_frame():
    """Build a per-participant baseline frame from master + vocal skill."""
    master = load_participant_master()
    vocal  = load_vocal_skill()

    # Keep only final analytic sample (participants with all 4 waves)
    from analysis._utils import build_aai_wide
    keep_ids = set(build_aai_wide()["SubjectID"])
    master = master[master["SubjectID"].isin(keep_ids)].reset_index(drop=True)

    # Use the baseline vocal score already stored in master
    df = master.copy()
    df = df.rename(columns={
        "Age_Years":                    "Age",
        "PriorTrainingYears":           "training_years",
        "CulturalID_Composite":         "cultural_id",
        "Baseline_VocalSkill_0to100":   "baseline_vocal",
    })

    # If Vocal Skill Scores sheet has more precise T1 measure, prefer that
    if "T1_Score" in vocal.columns:
        v = vocal[["SubjectID", "T1_Score"]].rename(columns={"T1_Score": "baseline_vocal_v"})
        df = df.merge(v, on="SubjectID", how="left")
        # Prefer the vocal-sheet value where present
        df["baseline_vocal"] = df["baseline_vocal_v"].fillna(df["baseline_vocal"])
        df = df.drop(columns=["baseline_vocal_v"])
    elif "Vocal_Score_T1" in vocal.columns:
        v = vocal[["SubjectID", "Vocal_Score_T1"]].rename(columns={"Vocal_Score_T1": "baseline_vocal_v"})
        df = df.merge(v, on="SubjectID", how="left")
        df["baseline_vocal"] = df["baseline_vocal_v"].fillna(df["baseline_vocal"])
        df = df.drop(columns=["baseline_vocal_v"])

    df["is_female"] = (df["Sex"].astype(str).str.lower() == "female").astype(int)
    df["second_year_plus"] = (df["AcademicYear"].astype(str)
                                .isin(["2", "3", "4", "Year2", "Year3", "Year4",
                                       "Sophomore", "Junior", "Senior"])).astype(int)

    return df


def t_test(df, col, group_col="Condition"):
    a = df.loc[df[group_col] == "A", col].dropna()
    b = df.loc[df[group_col] == "B", col].dropna()
    t, p = stats.ttest_ind(a, b, equal_var=False)
    return t, p, a.mean(), a.std(ddof=1), b.mean(), b.std(ddof=1), len(a), len(b)


def prop_test(df, col, group_col="Condition"):
    a = df.loc[df[group_col] == "A", col].dropna()
    b = df.loc[df[group_col] == "B", col].dropna()
    table = np.array([[int(a.sum()), int(len(a) - a.sum())],
                      [int(b.sum()), int(len(b) - b.sum())]])
    chi2, p, _, _ = stats.chi2_contingency(table)
    return chi2, p, 100 * a.mean(), 100 * b.mean(), len(a), len(b)


def main():
    log = get_logger("02_baseline")
    log.info("=" * 70)
    log.info("Module 02 — Baseline Balance (Table 2)")

    df = build_baseline_frame()
    n_A = int((df["Condition"] == "A").sum())
    n_B = int((df["Condition"] == "B").sum())
    log.info(f"Analytic sample: A n={n_A}, B n={n_B}")

    rows = []; comps = []

    # Age (continuous)
    t, p, mA, sA, mB, sB, nA, nB = t_test(df, "Age")
    rows.append({"Characteristic": "Age (years, M±SD)",
                 "Condition A": f"{mA:.1f}±{sA:.1f}", "Condition B": f"{mB:.1f}±{sB:.1f}",
                 "Test statistic": f"t={t:.2f}", "p": f"{p:.3f}"})
    comps += [compare_to_reference("Age A mean", mA, pt.TABLE2_TARGETS["age"]["A"][0], "mean"),
              compare_to_reference("Age B mean", mB, pt.TABLE2_TARGETS["age"]["B"][0], "mean"),
              compare_to_reference("Age p",       p, pt.TABLE2_TARGETS["age"]["p"],     "pvalue")]

    # Female %
    chi2, p, pA, pB, _, _ = prop_test(df, "is_female")
    rows.append({"Characteristic": "Female (%)",
                 "Condition A": f"{pA:.1f}", "Condition B": f"{pB:.1f}",
                 "Test statistic": f"χ²={chi2:.2f}", "p": f"{p:.3f}"})
    comps += [compare_to_reference("Female A %", pA, pt.TABLE2_TARGETS["female_pct"]["A"], "percentage"),
              compare_to_reference("Female B %", pB, pt.TABLE2_TARGETS["female_pct"]["B"], "percentage")]

    # Second year or above %
    chi2, p, pA, pB, _, _ = prop_test(df, "second_year_plus")
    rows.append({"Characteristic": "Second year or above (%)",
                 "Condition A": f"{pA:.1f}", "Condition B": f"{pB:.1f}",
                 "Test statistic": f"χ²={chi2:.2f}", "p": f"{p:.3f}"})

    # Prior training duration
    if "training_years" in df.columns:
        t, p, mA, sA, mB, sB, _, _ = t_test(df, "training_years")
        rows.append({"Characteristic": "Prior training duration (years, M±SD)",
                     "Condition A": f"{mA:.1f}±{sA:.1f}", "Condition B": f"{mB:.1f}±{sB:.1f}",
                     "Test statistic": f"t={t:.2f}", "p": f"{p:.3f}"})
        comps += [compare_to_reference("Train A M", mA, pt.TABLE2_TARGETS["training_years"]["A"][0], "mean"),
                  compare_to_reference("Train B M", mB, pt.TABLE2_TARGETS["training_years"]["B"][0], "mean")]

    # Prior cultural identification
    if "cultural_id" in df.columns:
        t, p, mA, sA, mB, sB, _, _ = t_test(df, "cultural_id")
        rows.append({"Characteristic": "Prior cultural identification (1–7, M±SD)",
                     "Condition A": f"{mA:.2f}±{sA:.2f}", "Condition B": f"{mB:.2f}±{sB:.2f}",
                     "Test statistic": f"t={t:.2f}", "p": f"{p:.3f}"})
        comps += [compare_to_reference("CultID A M", mA, pt.TABLE2_TARGETS["cultural_id"]["A"][0], "mean"),
                  compare_to_reference("CultID B M", mB, pt.TABLE2_TARGETS["cultural_id"]["B"][0], "mean")]

    # Baseline vocal skill
    t, p, mA, sA, mB, sB, _, _ = t_test(df, "baseline_vocal")
    rows.append({"Characteristic": "Baseline vocal skill (0–100, M±SD)",
                 "Condition A": f"{mA:.1f}±{sA:.1f}", "Condition B": f"{mB:.1f}±{sB:.1f}",
                 "Test statistic": f"t={t:.2f}", "p": f"{p:.3f}"})
    comps += [compare_to_reference("Vocal A M", mA, pt.TABLE2_TARGETS["baseline_vocal"]["A"][0], "mean"),
              compare_to_reference("Vocal B M", mB, pt.TABLE2_TARGETS["baseline_vocal"]["B"][0], "mean")]

    tbl = pd.DataFrame(rows)
    tbl.to_csv(pt.TABLES_DIR / "02_baseline_balance.csv", index=False)
    tbl.to_excel(pt.TABLES_DIR / "02_baseline_balance.xlsx", index=False)
    log.info("Saved: tables/02_baseline_balance.csv (and .xlsx)")

    print("\nTable 2. Participant Demographic and Baseline Characteristics")
    print(tbl.to_string(index=False))
    print_comparison(comps, "Table 2 estimated vs reference")

    log.info("Module 02 complete.\n")
    return tbl


if __name__ == "__main__":
    main()
