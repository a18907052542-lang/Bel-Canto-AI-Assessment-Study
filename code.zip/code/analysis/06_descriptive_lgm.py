"""
06_descriptive_lgm.py

Estimates the values reported in Table 5 — Descriptive statistics for AAI across four waves and
LGM estimates of linear slopes.

- Descriptives: mean and SD of composite AAI at T1..T4 per condition.
- Between-group t-tests at each wave.
- LGM: latent growth model with fixed factor loadings 0,1,2,3 for T1..T4.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from scipy import stats
import semopy

from analysis._utils import (build_aai_wide, compute_individual_slopes,
                             get_logger, compare_to_reference, print_comparison)
from config import reference_values as pt


def descriptives(wide, wave_col):
    a = wide.loc[wide["Condition"] == "A", wave_col]
    b = wide.loc[wide["Condition"] == "B", wave_col]
    return a.mean(), a.std(ddof=1), b.mean(), b.std(ddof=1), stats.ttest_ind(a, b, equal_var=False)


def fit_lgm_per_group(wide_group):
    """
    Fit a simple LGM with intercept + linear slope, loadings 0,1,2,3.
    Returns dict with slope mean, SE, p-value.
    Uses semopy's structural model on the wide-format data.
    """
    lgm_desc = """
    # Latent factors
    Icept =~ 1*AAI_T1 + 1*AAI_T2 + 1*AAI_T3 + 1*AAI_T4
    Slope =~ 0*AAI_T1 + 1*AAI_T2 + 2*AAI_T3 + 3*AAI_T4
    # Means and covariances
    Icept ~ 1
    Slope ~ 1
    """
    df = wide_group[["AAI_T1", "AAI_T2", "AAI_T3", "AAI_T4"]].astype(float)
    try:
        model = semopy.Model(lgm_desc)
        model.fit(df, obj="MLW")
        ins = model.inspect()
        # Slope mean
        slope_row = ins[(ins["lval"] == "Slope") & (ins["op"] == "~") & (ins["rval"] == "1")]
        if len(slope_row) > 0:
            b = float(slope_row["Estimate"].values[0])
            se = float(slope_row["Std. Err"].values[0]) if "Std. Err" in slope_row.columns else np.nan
            # Wald p-value
            if not np.isnan(se) and se > 0:
                z = b / se
                p = 2 * (1 - stats.norm.cdf(abs(z)))
            else:
                p = np.nan
            return {"beta": b, "SE": se, "p": p, "converged": True}
    except Exception as e:
        pass

    # Fallback: individual OLS slopes, then mean/SE
    slopes = compute_individual_slopes(wide_group)["AAI_slope"]
    b = slopes.mean(); se = slopes.std(ddof=1) / np.sqrt(len(slopes))
    if se > 0:
        t = b / se
        p = 2 * (1 - stats.t.cdf(abs(t), df=len(slopes) - 1))
    else:
        p = np.nan
    return {"beta": b, "SE": se, "p": p, "converged": False}


def main():
    log = get_logger("06_descriptive_lgm")
    log.info("=" * 70)
    log.info("Module 06 — Descriptives + LGM (Table 5)")

    wide = build_aai_wide()

    rows = []
    comps = []
    for wave_num, wave_col in [(1, "AAI_T1"), (2, "AAI_T2"), (3, "AAI_T3"), (4, "AAI_T4")]:
        mA, sA, mB, sB, tstat = descriptives(wide, wave_col)
        rows.append({
            "Wave": f"T{wave_num}",
            "Condition A M(SD)": f"{mA:.2f}({sA:.2f})",
            "Condition B M(SD)": f"{mB:.2f}({sB:.2f})",
            "t between": round(tstat.statistic, 2),
            "p": round(tstat.pvalue, 4),
        })
        # Compare
        tgt = pt.TABLE5_TARGETS[f"T{wave_num}"]
        comps.append(compare_to_reference(f"T{wave_num} A M", mA, tgt["A"][0], "mean"))
        comps.append(compare_to_reference(f"T{wave_num} B M", mB, tgt["B"][0], "mean"))

    log.info("Fitting LGM for each condition ...")
    lgm_A = fit_lgm_per_group(wide[wide["Condition"] == "A"])
    lgm_B = fit_lgm_per_group(wide[wide["Condition"] == "B"])
    log.info(f"Condition A slope: β = {lgm_A['beta']:.3f} (SE={lgm_A['SE']:.3f}, p={lgm_A['p']:.3f}, "
             f"{'converged' if lgm_A['converged'] else 'OLS fallback'})")
    log.info(f"Condition B slope: β = {lgm_B['beta']:.3f} (SE={lgm_B['SE']:.3f}, p={lgm_B['p']:.3f}, "
             f"{'converged' if lgm_B['converged'] else 'OLS fallback'})")

    rows.append({
        "Wave": "LGM slope β",
        "Condition A M(SD)": f"{lgm_A['beta']:+.3f} (SE {lgm_A['SE']:.3f})",
        "Condition B M(SD)": f"{lgm_B['beta']:+.3f} (SE {lgm_B['SE']:.3f})",
        "t between": "—", "p": "—",
    })
    rows.append({
        "Wave": "p value for β",
        "Condition A M(SD)": f"{lgm_A['p']:.3f}",
        "Condition B M(SD)": f"{lgm_B['p']:.3f}",
        "t between": "—", "p": "—",
    })

    # Between-group slope difference and Cohen's d
    slopes_A = compute_individual_slopes(wide[wide["Condition"] == "A"])["AAI_slope"]
    slopes_B = compute_individual_slopes(wide[wide["Condition"] == "B"])["AAI_slope"]
    delta_beta = slopes_B.mean() - slopes_A.mean()
    pooled_sd  = np.sqrt(((len(slopes_A) - 1) * slopes_A.var(ddof=1) +
                          (len(slopes_B) - 1) * slopes_B.var(ddof=1)) /
                         (len(slopes_A) + len(slopes_B) - 2))
    cohen_d = delta_beta / pooled_sd

    log.info(f"Between-condition slope Δβ = {delta_beta:.3f}, Cohen's d = {cohen_d:.2f} "
             f"(reference: Δβ=.252, d=1.02)")

    comps += [
        compare_to_reference("Slope A β",   lgm_A["beta"], pt.TABLE5_TARGETS["slope_A"]["beta"], "regression"),
        compare_to_reference("Slope B β",   lgm_B["beta"], pt.TABLE5_TARGETS["slope_B"]["beta"], "regression"),
        compare_to_reference("Δβ",          delta_beta,     pt.TABLE5_TARGETS["slope_diff"]["delta_beta"], "regression"),
        compare_to_reference("Cohen's d",   cohen_d,        pt.TABLE5_TARGETS["slope_diff"]["cohen_d"], "correlation"),
    ]
    print_comparison(comps, "Table 5 estimated vs reference")

    tbl = pd.DataFrame(rows)
    tbl.to_csv(pt.TABLES_DIR / "06_table5_descriptive_lgm.csv", index=False)
    log.info("Saved: tables/06_table5_descriptive_lgm.csv")

    print("\nTable 5. Descriptive Statistics + LGM Slopes")
    print(tbl.to_string(index=False))

    log.info("Module 06 complete.\n")

    return {"lgm_A": lgm_A, "lgm_B": lgm_B, "delta_beta": delta_beta, "cohen_d": cohen_d}


if __name__ == "__main__":
    main()
