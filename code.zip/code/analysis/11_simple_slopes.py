"""
11_simple_slopes.py

Produces Figure 11 — Simple slopes of the moderating effect of prior cultural
identification strength on the relationship between assessment condition and
the AAI linear slope.

At -1SD ID: effect = -0.121 (SE=.061, p=.048)
At +1SD ID: effect = -0.405 (SE=.058, p<.001)
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
from scipy import stats

from analysis._utils import apply_style, get_logger, compare_to_reference, print_comparison
from config import reference_values as pt


def load_analytic_frame():
    """Rebuild the analytic frame from module 09."""
    from importlib import util
    spec = util.spec_from_file_location(
        "mediation", Path(__file__).parent / "09_moderated_mediation.py")
    mod = util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.build_analytic_frame()


def compute_simple_slopes(df):
    """
    Fit β_i = γ0 + γ1·Cond + γ2·ID + γ3·Cond·ID + ε and compute the effect of
    Cond at ID = -1SD and ID = +1SD.

        Effect of Cond @ ID = z  is  γ1 + γ3·z.
    """
    X = sm.add_constant(df[["Cond", "ID_centered", "Cond_x_ID"]])
    y = df["AAI_slope"]
    m = sm.OLS(y, X).fit()

    g1 = m.params["Cond"]; g3 = m.params["Cond_x_ID"]
    cov = m.cov_params()

    id_sd = df["ID_centered"].std(ddof=1)
    low, high = -id_sd, id_sd

    def effect_and_se(z):
        eff = g1 + g3 * z
        var = (cov.loc["Cond", "Cond"]
               + 2 * z * cov.loc["Cond", "Cond_x_ID"]
               + z**2 * cov.loc["Cond_x_ID", "Cond_x_ID"])
        se = np.sqrt(var)
        p  = 2 * (1 - stats.norm.cdf(abs(eff / se)))
        return eff, se, p

    eff_low,  se_low,  p_low  = effect_and_se(low)
    eff_high, se_high, p_high = effect_and_se(high)

    return {
        "id_sd": id_sd,
        "low":   {"z": low,  "effect": eff_low,  "SE": se_low,  "p": p_low},
        "high":  {"z": high, "effect": eff_high, "SE": se_high, "p": p_high},
        "model": m,
    }


def plot_simple_slopes(df, results, out_path):
    apply_style()
    fig, ax = plt.subplots(figsize=(9, 6))

    m = results["model"]
    g0 = m.params["const"]; g1 = m.params["Cond"]
    g2 = m.params["ID_centered"]; g3 = m.params["Cond_x_ID"]

    # Predicted AAI slope for each Cond × ID
    conds = np.array([0, 1])
    id_sd = results["id_sd"]
    id_low_val  = -id_sd
    id_high_val = +id_sd

    y_low  = g0 + g1 * conds + g2 * id_low_val  + g3 * conds * id_low_val
    y_high = g0 + g1 * conds + g2 * id_high_val + g3 * conds * id_high_val

    ax.plot(conds, y_low,  "o-", color=pt.COLORS["gray"], lw=2.5, markersize=10,
            label=f"Low ID (-1 SD)   effect = {results['low']['effect']:+.3f}, p={results['low']['p']:.3f}")
    ax.plot(conds, y_high, "s-", color=pt.COLORS["condB"], lw=2.5, markersize=10,
            label=f"High ID (+1 SD)  effect = {results['high']['effect']:+.3f}, p={results['high']['p']:.4f}")

    ax.axhline(0, ls="--", color="#333333", lw=1, alpha=0.6)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Condition B\n(opaque)", "Condition A\n(transparent)"], fontsize=11)
    ax.set_ylabel("Predicted AAI linear slope (β)", fontsize=11.5)
    ax.set_xlabel("Assessment Condition", fontsize=11.5)
    ax.set_title("Figure 11. Simple Slopes — Moderating Effect of Cultural Identification",
                 fontsize=13, fontweight="bold", color=pt.COLORS["condA"])
    ax.legend(loc="upper right", fontsize=10, frameon=True)
    ax.grid(True, alpha=0.35)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)

    fig.tight_layout()
    fig.savefig(out_path, dpi=pt.FIGURE_STYLE["dpi"], bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main():
    log = get_logger("11_simple_slopes")
    log.info("=" * 70)
    log.info("Module 11 — Simple Slopes (Figure 11)")

    df = load_analytic_frame()
    results = compute_simple_slopes(df)

    log.info(f"Cultural ID SD = {results['id_sd']:.3f}")
    log.info(f"Low ID  (-1 SD): effect = {results['low']['effect']:+.4f}, "
             f"SE={results['low']['SE']:.3f}, p={results['low']['p']:.4g}")
    log.info(f"High ID (+1 SD): effect = {results['high']['effect']:+.4f}, "
             f"SE={results['high']['SE']:.3f}, p={results['high']['p']:.4g}")

    comps = [
        compare_to_reference("Low ID effect",  results["low"]["effect"],
                          pt.SIMPLE_SLOPES["low_ID"]["effect"], "regression"),
        compare_to_reference("High ID effect", results["high"]["effect"],
                          pt.SIMPLE_SLOPES["high_ID"]["effect"], "regression"),
    ]
    print_comparison(comps, "Simple slopes estimated vs reference")

    tbl = pd.DataFrame([
        {"Level": "Low ID (-1 SD)",  "Effect": round(results["low"]["effect"], 3),
         "SE": round(results["low"]["SE"], 3),  "p": round(results["low"]["p"], 4),
         "Paper": pt.SIMPLE_SLOPES["low_ID"]["effect"]},
        {"Level": "High ID (+1 SD)", "Effect": round(results["high"]["effect"], 3),
         "SE": round(results["high"]["SE"], 3), "p": round(results["high"]["p"], 4),
         "Paper": pt.SIMPLE_SLOPES["high_ID"]["effect"]},
    ])
    tbl.to_csv(pt.TABLES_DIR / "11_simple_slopes.csv", index=False)
    log.info("Saved: tables/11_simple_slopes.csv")

    plot_simple_slopes(df, results, pt.FIGURES_DIR / "Fig11_SimpleSlopes.png")
    log.info("Saved: figures/Fig11_SimpleSlopes.png")
    log.info("Module 11 complete.\n")


if __name__ == "__main__":
    main()
