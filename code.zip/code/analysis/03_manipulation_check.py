"""
03_manipulation_check.py

Estimates the manipulation check statistics defined in the study protocol:
89.2% of Condition A vs 7.1% of Condition B answered all three items correctly.
χ²(1) = 241.6, p < .001, Cramér's V = .82.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

from analysis._utils import (load_manipulation_check, apply_style,
                             get_logger, compare_to_reference, print_comparison)
from config import reference_values as pt


def cramers_v(chi2, n, r, c):
    return np.sqrt(chi2 / (n * (min(r, c) - 1)))


def make_bar_figure(pct_A, pct_B, chi2, p, v, out_path):
    apply_style()
    fig, ax = plt.subplots(figsize=(7.5, 5))
    conds = ["Condition A\n(transparent)", "Condition B\n(opaque)"]
    pcts  = [pct_A, pct_B]
    colors = [pt.COLORS["condA"], pt.COLORS["condB"]]

    bars = ax.bar(conds, pcts, color=colors, edgecolor="#111111", linewidth=1.1, width=0.55)

    for bar, pct in zip(bars, pcts):
        ax.text(bar.get_x() + bar.get_width()/2, pct + 1.5,
                f"{pct:.1f}%", ha="center", va="bottom",
                fontsize=13, fontweight="bold")

    ax.set_ylabel("Percentage answering all three items correctly")
    ax.set_ylim(0, 100)
    ax.set_title("Manipulation Check — Recognition of Standard Source (Post-T1)",
                 fontsize=12.5, fontweight="bold", color=pt.COLORS["condA"])
    ax.grid(axis="y", alpha=0.3)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)

    p_str = "< .001" if p < 0.001 else f"= {p:.3f}"
    stat_text = (f"χ²(1) = {chi2:.1f},  p {p_str}\n"
                 f"Cramér's V = {v:.2f}   (reference: χ²=241.6, V=.82)")
    ax.text(0.5, -0.20, stat_text, transform=ax.transAxes, ha="center",
            fontsize=10, color=pt.COLORS["gray"], style="italic")

    fig.savefig(out_path, dpi=pt.FIGURE_STYLE["dpi"], bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main():
    log = get_logger("03_manip")
    log.info("=" * 70)
    log.info("Module 03 — Manipulation Check")

    mc = load_manipulation_check()

    # Correct = all three items answered correctly
    if "MC_All_Correct" in mc.columns:
        correct_col = "MC_All_Correct"
    else:
        # Build it: MC_Q1 == 1 & MC_Q2 == 1 & MC_Q3 == 1 (yes/no expectations differ by condition)
        raise KeyError("Column MC_All_Correct not found in manipulation check sheet.")

    A = mc[mc["Condition"] == "A"]
    B = mc[mc["Condition"] == "B"]
    nA, nB = len(A), len(B)
    pct_A = 100 * A[correct_col].mean()
    pct_B = 100 * B[correct_col].mean()

    log.info(f"A: {int(A[correct_col].sum())}/{nA} = {pct_A:.1f}% correct")
    log.info(f"B: {int(B[correct_col].sum())}/{nB} = {pct_B:.1f}% correct")

    # Chi-square test
    table = np.array([[int(A[correct_col].sum()), nA - int(A[correct_col].sum())],
                      [int(B[correct_col].sum()), nB - int(B[correct_col].sum())]])
    chi2, p, _, _ = stats.chi2_contingency(table, correction=False)
    v = cramers_v(chi2, nA + nB, 2, 2)

    log.info(f"χ²(1) = {chi2:.2f}, p = {p:.4g}, Cramér's V = {v:.3f}")

    comps = [
        compare_to_reference("A % correct", pct_A, pt.MANIP_CHECK["A_correct_pct"], "percentage"),
        compare_to_reference("B % correct", pct_B, pt.MANIP_CHECK["B_correct_pct"], "percentage"),
        compare_to_reference("χ²",          chi2, pt.MANIP_CHECK["chi2"],           "chi2"),
        compare_to_reference("Cramér's V",   v,    pt.MANIP_CHECK["cramer_v"],       "correlation"),
    ]
    print_comparison(comps, "Manipulation Check vs reference")

    # Save results
    out_row = {
        "n_A": nA, "n_A_correct": int(A[correct_col].sum()), "A_pct": round(pct_A, 2),
        "n_B": nB, "n_B_correct": int(B[correct_col].sum()), "B_pct": round(pct_B, 2),
        "chi2": round(chi2, 2), "df": 1, "p": p, "cramers_V": round(v, 3),
        "reference_A_pct": pt.MANIP_CHECK["A_correct_pct"], "reference_B_pct": pt.MANIP_CHECK["B_correct_pct"],
        "reference_chi2": pt.MANIP_CHECK["chi2"], "reference_V": pt.MANIP_CHECK["cramer_v"],
    }
    pd.DataFrame([out_row]).to_csv(pt.TABLES_DIR / "03_manipulation_check.csv", index=False)
    log.info("Saved: tables/03_manipulation_check.csv")

    make_bar_figure(pct_A, pct_B, chi2, p, v, pt.FIGURES_DIR / "Fig_ManipCheck.png")
    log.info("Saved: figures/Fig_ManipCheck.png")
    log.info("Module 03 complete.\n")

    return out_row


if __name__ == "__main__":
    main()
