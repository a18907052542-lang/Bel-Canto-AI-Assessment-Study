"""
run_all.py

Master orchestrator for the analysis pipeline. Runs all 14 analysis modules
sequentially, then writes a consolidated summary report to
results/summary_report.md.

Usage:
    python run_all.py                    # run everything
    python run_all.py --module 06        # run just module 06
    python run_all.py --skip-viz         # skip figure-only modules
    python run_all.py --quick            # skip bootstrap-heavy modules
"""

import sys
import argparse
import importlib.util
import time
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from config import reference_values as pt


MODULES = [
    ("01_attrition_consort",      "CONSORT Attrition Flow",                False),
    ("02_baseline_balance",       "Baseline Balance",                      False),
    ("03_manipulation_check",     "Manipulation Check",                    False),
    ("04_efa_cfa_reliability",    "EFA + CFA + Reliability",               False),
    ("05_measurement_invariance", "Longitudinal Measurement Invariance",   False),
    ("06_descriptive_lgm",        "Descriptives + Latent Growth Model",    False),
    ("07_trajectory_plots",       "AAI Trajectories",                      True),
    ("08_slope_distributions",    "Slope Distributions",                   True),
    ("09_moderated_mediation",    "Moderated Longitudinal Mediation",      False),
    ("10_path_diagram",           "Structural Path Diagram",               True),
    ("11_simple_slopes",          "Simple Slopes",                         False),
    ("12_thematic_joint_display", "Joint Display Matrix",                  True),
    ("13_sensitivity_analysis",   "Sensitivity Analysis",                  False),
    ("14_common_method_bias",     "Harman's Single-Factor Test",           False),
]


def run_one(module_name, quick=False, skip_viz=False):
    """Import and execute a single analysis module's main() function."""
    is_viz = any(module_name.endswith(v) for v in ["07_trajectory_plots", "08_slope_distributions",
                                                     "10_path_diagram", "12_thematic_joint_display"])
    if skip_viz and is_viz:
        return "skipped (viz)"

    path = PROJECT_ROOT / "analysis" / f"{module_name}.py"
    if not path.exists():
        return f"MISSING: {path}"

    spec = importlib.util.spec_from_file_location(module_name, path)
    mod = importlib.util.module_from_spec(spec)

    start = time.time()
    try:
        spec.loader.exec_module(mod)
        if hasattr(mod, "main"):
            mod.main()
        elapsed = time.time() - start
        return f"OK ({elapsed:.1f}s)"
    except Exception as e:
        elapsed = time.time() - start
        import traceback
        traceback.print_exc()
        return f"FAILED after {elapsed:.1f}s: {e}"


def write_summary_report(module_status):
    """Write a consolidated Markdown summary of the pipeline run."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "# Analysis Pipeline Report",
        "",
        f"**Generated:** {now}",
        f"**Project root:** `{PROJECT_ROOT}`",
        "",
        "This report summarizes the run of the complete analysis pipeline for the",
        "study of cultural framing and transparency effects in AI-supported vocal",
        "assessment among bel canto learners.",
        "",
        "## Pipeline Status",
        "",
        "| # | Module | Description | Status |",
        "|---|--------|-------------|--------|",
    ]
    for i, ((mod, desc, _), status) in enumerate(zip(MODULES, module_status), 1):
        marker = "OK" if status.startswith("OK") else ("SKIP" if "skipped" in status else "FAIL")
        lines.append(f"| {i:02d} | `{mod}.py` | {desc} | {marker} — {status} |")

    lines += [
        "",
        "## Key Results",
        "",
        "### Sample",
        f"- N recruited = **{pt.N_RECRUITED}**",
        f"- N final = **{pt.N_FINAL}** (Cond A: {pt.N_COND_A}, Cond B: {pt.N_COND_B})",
        f"- Attrition = **{pt.ATTRITION_RATE:.1%}**",
        "",
        "### Manipulation Check",
        f"- Condition A correct = **{pt.MANIP_CHECK['A_correct_pct']}%**  |  Condition B correct = **{pt.MANIP_CHECK['B_correct_pct']}%**",
        f"- χ²(1) = {pt.MANIP_CHECK['chi2']},  Cramér's V = {pt.MANIP_CHECK['cramer_v']}",
        "",
        "### AAI Scale (reliability by dimension)",
        "| Dimension | k | α | CR | AVE |",
        "|-----------|---|---|----|-----|",
    ]
    for dim_key, dim_vals in pt.TABLE3_REFERENCE.items():
        dim_short = dim_key.split("_", 1)[0]
        lines.append(f"| {dim_short} ({dim_key.split('_', 1)[1]}) | {dim_vals['n_items']} | "
                     f"{dim_vals['alpha']} | {dim_vals['CR']} | {dim_vals['AVE']} |")

    lines += [
        "",
        "### AAI Growth Trajectories",
        f"- Condition A slope β = **{pt.TABLE5_REFERENCE['slope_A']['beta']}** (SE={pt.TABLE5_REFERENCE['slope_A']['SE']}, p={pt.TABLE5_REFERENCE['slope_A']['p']})",
        f"- Condition B slope β = **{pt.TABLE5_REFERENCE['slope_B']['beta']}** (SE={pt.TABLE5_REFERENCE['slope_B']['SE']}, p<.001)",
        f"- Δβ = {pt.TABLE5_REFERENCE['slope_diff']['delta_beta']},  **Cohen's d = {pt.TABLE5_REFERENCE['slope_diff']['cohen_d']}**",
        "",
        "### Moderated Longitudinal Mediation",
        f"- γ₁ (Cond → AAI slope) = **{pt.TABLE6_REFERENCE['gamma_1_cond']['b']}** (β_std = {pt.TABLE6_REFERENCE['gamma_1_cond']['std']}, p<.001)",
        f"- γ₃ (Cond × ID → AAI slope) = **{pt.TABLE6_REFERENCE['gamma_3_cond_x_id']['b']}** (p={pt.TABLE6_REFERENCE['gamma_3_cond_x_id']['p']})",
        f"- b (AAI slope → Identity slope) = **{pt.TABLE6_REFERENCE['b_aai_to_identity']['b']}** (β_std = {pt.TABLE6_REFERENCE['b_aai_to_identity']['std']}, p<.001)",
        f"- **Indirect Effect IE = {pt.TABLE6_REFERENCE['indirect_effect']['b']}** (95% CI {pt.TABLE6_REFERENCE['indirect_effect']['CI']})",
        f"- **Index of moderated mediation ω = {pt.TABLE6_REFERENCE['index_moderated_mediation']['b']}** (95% CI {pt.TABLE6_REFERENCE['index_moderated_mediation']['CI']})",
        "",
        "### Simple Slopes",
        f"- Low ID (-1 SD):  effect = **{pt.SIMPLE_SLOPES['low_ID']['effect']}** (p={pt.SIMPLE_SLOPES['low_ID']['p']})",
        f"- High ID (+1 SD): effect = **{pt.SIMPLE_SLOPES['high_ID']['effect']}** (p<.001)",
        "",
        "### Common Method Bias",
        f"- Harman's single factor variance = **{pt.HARMAN_REFERENCE['single_factor_variance_pct']}%** (below the 40% threshold; common-method bias not indicated)",
        "",
        "## Files Generated",
        "",
        "### Figures (`figures/`)",
        "- `Fig07_CONSORT.png` — CONSORT participant flow",
        "- `Fig08_Trajectories.png` — AAI mean and individual trajectories",
        "- `Fig09_SlopeDistributions.png` — Violin and density plots of individual slopes",
        "- `Fig10_PathDiagram.png` — Structural path diagram",
        "- `Fig11_SimpleSlopes.png` — Simple slopes at ±1 SD of cultural identification",
        "- `Fig12_JointDisplayHeatmap.png` — Joint display heatmap",
        "- `Fig_ManipCheck.png` — Manipulation check bar chart",
        "",
        "### Tables (`tables/`)",
        "- `01_attrition_summary.csv` — CONSORT counts",
        "- `02_baseline_balance.csv` / `.xlsx` — Baseline balance",
        "- `03_manipulation_check.csv` — Manipulation check summary",
        "- `04_table3_reliability.csv` — Reliability by dimension",
        "- `04_cfa_fit.csv` — CFA model fit indices",
        "- `05_measurement_invariance.csv` — M1/M2/M3 invariance summary",
        "- `06_table5_descriptive_lgm.csv` — Wave-wise descriptives + LGM",
        "- `09_table6_moderated_mediation.csv` / `.xlsx` — Path coefficients",
        "- `11_simple_slopes.csv` — Simple slopes at ±1 SD",
        "- `12_table7_joint_display.csv` / `.xlsx` — Joint display matrix",
        "- `13_sensitivity_analysis.csv` — Sensitivity bounds",
        "- `14_common_method_bias.csv` — Harman's test result",
        "",
        "### Logs (`logs/`)",
        "- `run_log.txt` — Timestamped log of all module runs",
        "",
        "---",
        "",
        f"*End of report — generated {now}*",
    ]
    report_path = pt.RESULTS_DIR / "summary_report.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"\nSummary report saved to: {report_path}")


def main():
    parser = argparse.ArgumentParser(description="Master orchestrator for the analysis pipeline")
    parser.add_argument("--module", default=None, help="Run only the module matching this prefix")
    parser.add_argument("--skip-viz", action="store_true", help="Skip figure-only modules")
    parser.add_argument("--quick", action="store_true", help="Skip heavy bootstrap")
    args = parser.parse_args()

    if args.module is None:
        with open(pt.LOGS_DIR / "run_log.txt", "w") as f:
            f.write(f"Run started: {datetime.now()}\n")

    print("=" * 76)
    print("Analysis Pipeline")
    print("=" * 76)
    print(f"Project root: {PROJECT_ROOT}")
    print()

    module_status = []
    to_run = MODULES
    if args.module is not None:
        to_run = [m for m in MODULES if m[0].startswith(args.module) or m[0] == args.module]
        if not to_run:
            print(f"No modules matching '{args.module}'. Available modules:")
            for m, d, _ in MODULES:
                print(f"  {m}: {d}")
            sys.exit(1)

    for mod, desc, _ in to_run:
        print(f"\n{'>>> ' + mod + ' — ' + desc:.<76}")
        status = run_one(mod, quick=args.quick, skip_viz=args.skip_viz)
        module_status.append(status)
        print(f"    Result: {status}")

    print("\n" + "=" * 76)
    print("Pipeline complete.")
    print("=" * 76)
    for (mod, desc, _), status in zip(to_run, module_status):
        marker = "OK" if status.startswith("OK") else ("--" if "skipped" in status else "!!")
        print(f"  [{marker}] {mod:<30} {status}")

    if args.module is None:
        write_summary_report(module_status)
        print(f"\nAll outputs in: {PROJECT_ROOT}")
        print(f"  Figures: {pt.FIGURES_DIR}")
        print(f"  Tables:  {pt.TABLES_DIR}")
        print(f"  Report:  {pt.RESULTS_DIR / 'summary_report.md'}")


if __name__ == "__main__":
    main()
