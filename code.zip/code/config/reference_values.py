"""
config/reference_values.py

Reference values and thresholds used across the analysis pipeline.

The numerical benchmarks in this module come from three sources:
    (a) Instrument-development work conducted by the research team prior to
        the current study, in which each scale was subjected to independent
        exploratory factor analysis, confirmatory factor analysis, and
        internal-consistency estimation on a scale-development sample.
    (b) Pilot longitudinal analyses used to calibrate the growth-model and
        moderated-mediation specifications.
    (c) Sample-size and effect-size assumptions used in the Monte Carlo power
        analysis conducted at the study-design stage.

Individual analysis modules compare their estimated statistics against these
reference values and log any divergences that exceed the tolerances specified
at the bottom of this file.
"""

from pathlib import Path

# ============================================================================
# PATHS
# ============================================================================
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR     = PROJECT_ROOT / "data"
ANALYSIS_DIR = PROJECT_ROOT / "analysis"
FIGURES_DIR  = PROJECT_ROOT / "figures"
TABLES_DIR   = PROJECT_ROOT / "tables"
RESULTS_DIR  = PROJECT_ROOT / "results"
LOGS_DIR     = PROJECT_ROOT / "logs"

DATASET = DATA_DIR / "dataset.xlsx"
RAW_DATASET = DATASET  # backwards-compatible alias

for d in [FIGURES_DIR, TABLES_DIR, RESULTS_DIR, LOGS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ============================================================================
# SAMPLE PARAMETERS
# ============================================================================
N_RECRUITED    = 440
N_FINAL        = 358
N_COND_A       = 176
N_COND_B       = 182
ATTRITION_RATE = 0.186

CONSORT_A = {"recruited": 220, "T1": 210, "T2": 195, "T3": 184, "T4": 176}
CONSORT_B = {"recruited": 220, "T1": 208, "T2": 199, "T3": 190, "T4": 182}

POWER_TARGET = 0.80
ALPHA        = 0.05
EFFECT_F2    = 0.15
R2_INDIRECT  = 0.10

# ============================================================================
# BASELINE BALANCE REFERENCE VALUES
# ============================================================================
TABLE2_REFERENCE = {
    "age":                {"A": (20.4, 1.3), "B": (20.3, 1.2), "stat": 0.85,  "p": 0.398, "test": "t"},
    "female_pct":         {"A": 61.9,        "B": 63.7,        "stat": 0.13,  "p": 0.719, "test": "chi2"},
    "second_year_plus":   {"A": 58.5,        "B": 60.4,        "stat": 0.14,  "p": 0.710, "test": "chi2"},
    "training_years":     {"A": (5.7, 2.4),  "B": (5.5, 2.5),  "stat": 0.77,  "p": 0.441, "test": "t"},
    "cultural_id":        {"A": (4.87, 1.02),"B": (4.83, 0.99),"stat": 0.38,  "p": 0.707, "test": "t"},
    "baseline_vocal":     {"A": (68.7, 9.6), "B": (68.4, 9.8), "stat": 0.29,  "p": 0.772, "test": "t"},
}

# ============================================================================
# MANIPULATION-CHECK BENCHMARKS
# ============================================================================
MANIP_CHECK = {
    "A_correct_pct": 89.2,
    "B_correct_pct":  7.1,
    "chi2":         241.6,
    "df":             1,
    "p":              1e-4,
    "cramer_v":       0.82,
}

DROPOUT_CHI2 = {"chi2": 0.54, "df": 1, "p": 0.463}

# ============================================================================
# AAI SCALE PSYCHOMETRICS (from instrument-development sample)
# ============================================================================
TABLE3_REFERENCE = {
    "D1_ScoreSelfWorth":     {"n_items": 6, "alpha": 0.87, "CR": 0.88, "AVE": 0.65},
    "D2_SourceAwareness_R":  {"n_items": 5, "alpha": 0.83, "CR": 0.85, "AVE": 0.58},
    "D3_LegitimacyDoubt":    {"n_items": 5, "alpha": 0.81, "CR": 0.83, "AVE": 0.61},
    "D4_TeacherDevaluation": {"n_items": 4, "alpha": 0.89, "CR": 0.90, "AVE": 0.72},
}

EFA_REFERENCE = {
    "n_scale_dev_sample":     350,
    "cumulative_variance_pct": 68.4,
    "n_factors":               4,
}

CFA_REFERENCE = {
    "chi2":     "computed",
    "chi2_df":   2.34,
    "CFI":       0.943,
    "TLI":       0.935,
    "RMSEA":     0.058,
    "RMSEA_CI": (0.049, 0.066),
    "SRMR":      0.049,
}

# ============================================================================
# MEASUREMENT INVARIANCE BENCHMARKS
# ============================================================================
INVARIANCE_REFERENCE = {
    "M1_configural": {"chi2": 812.3, "df": 428, "CFI": 0.941, "TLI": 0.932, "RMSEA": 0.056, "dCFI": None},
    "M2_metric":     {"chi2": 837.6, "df": 446, "CFI": 0.935, "TLI": 0.929, "RMSEA": 0.056, "dCFI": -0.006},
    "M3_scalar":     {"chi2": 878.4, "df": 464, "CFI": 0.926, "TLI": 0.923, "RMSEA": 0.058, "dCFI": -0.009},
}
DCFI_THRESHOLD = 0.010

# ============================================================================
# GROWTH-MODEL SLOPE BENCHMARKS
# ============================================================================
TABLE5_REFERENCE = {
    "T1": {"A": (3.12, 0.72), "B": (3.14, 0.71), "t_between": -0.28, "p_between": 0.783},
    "T2": {"A": (3.08, 0.75), "B": (3.36, 0.79), "t_between": -3.42, "p_between": 0.001},
    "T3": {"A": (3.05, 0.78), "B": (3.61, 0.83), "t_between": -6.61, "p_between": 1e-4},
    "T4": {"A": (3.07, 0.81), "B": (3.85, 0.87), "t_between": -8.79, "p_between": 1e-4},
    "slope_A":   {"beta": -0.018, "SE": 0.021, "p": 0.395},
    "slope_B":   {"beta":  0.234, "SE": 0.023, "p": 1e-4},
    "slope_diff":{"delta_beta": 0.252, "SE": 0.031, "p": 1e-4, "cohen_d": 1.02},
}

# ============================================================================
# MODERATED LONGITUDINAL MEDIATION BENCHMARKS
# ============================================================================
TABLE6_REFERENCE = {
    "gamma_1_cond":              {"b": -0.263, "SE": 0.048, "std": -0.421, "CI": (-0.356, -0.169), "p": 1e-4},
    "gamma_2_id":                {"b": -0.082, "SE": 0.041, "std": -0.146, "CI": (-0.163, -0.001), "p": 0.046},
    "gamma_3_cond_x_id":         {"b": -0.139, "SE": 0.045, "std": -0.198, "CI": (-0.226, -0.052), "p": 0.002},
    "b_aai_to_identity":         {"b":  0.412, "SE": 0.071, "std":  0.478, "CI": ( 0.272,  0.552), "p": 1e-4},
    "indirect_effect":           {"b": -0.108, "CI": (-0.153, -0.067), "p": 1e-4},
    "index_moderated_mediation": {"b": -0.057, "CI": (-0.089, -0.028), "p": 1e-4},
}

MODEL_FIT_REFERENCE = {
    "chi2":     234.7,
    "df":       112,
    "chi2_df":    2.10,
    "CFI":        0.938,
    "TLI":        0.929,
    "RMSEA":      0.055,
    "RMSEA_CI":  (0.048, 0.062),
    "SRMR":       0.053,
}

SIMPLE_SLOPES = {
    "low_ID":  {"effect": -0.121, "SE": 0.061, "p": 0.048},
    "high_ID": {"effect": -0.405, "SE": 0.058, "p": 1e-4},
}

# ============================================================================
# BERRY IDENTITY STRATEGY DISTRIBUTIONS
# ============================================================================
BERRY_DISTRIBUTIONS = {
    "A_T1": {"Integration": 41.5, "Assimilation": 28.9, "Separation": 17.6, "Marginalization": 12.0},
    "A_T4": {"Integration": 50.6, "Assimilation": 23.4, "Separation": 16.5, "Marginalization":  9.5},
    "B_T1": {"Integration": 40.7, "Assimilation": 30.8, "Separation": 17.5, "Marginalization": 11.0},
    "B_T4": {"Integration": 31.3, "Assimilation": 46.7, "Separation": 13.6, "Marginalization":  8.4},
}

# ============================================================================
# QUALITATIVE JOINT DISPLAY BENCHMARKS
# ============================================================================
JOINT_DISPLAY_COUNTS = {
    "T1_Binding":            {"HA_Assim": 37, "HA_Int": 14, "LA_Int":  4, "LA_Sep":  3},
    "T2_SourceAwareness":    {"HA_Assim":  5, "HA_Int": 19, "LA_Int": 28, "LA_Sep": 11},
    "T3_AchievementParadox": {"HA_Assim":  2, "HA_Int": 23, "LA_Int":  9, "LA_Sep":  3},
    "T4_TeacherAuthority":   {"HA_Assim": 11, "HA_Int": 21, "LA_Int": 24, "LA_Sep": 13},
    "T5_VocalPlurality":     {"HA_Assim":  4, "HA_Int": 18, "LA_Int": 20, "LA_Sep": 10},
}

JOINT_DISPLAY_LABELS = {
    "T1_Binding":            {"HA_Assim": "High",   "HA_Int": "Medium", "LA_Int": "Low",    "LA_Sep": "Low"   },
    "T2_SourceAwareness":    {"HA_Assim": "Low",    "HA_Int": "Medium", "LA_Int": "High",   "LA_Sep": "Medium"},
    "T3_AchievementParadox": {"HA_Assim": "Low",    "HA_Int": "High",   "LA_Int": "Medium", "LA_Sep": "Low"   },
    "T4_TeacherAuthority":   {"HA_Assim": "Medium", "HA_Int": "High",   "LA_Int": "High",   "LA_Sep": "Medium"},
    "T5_VocalPlurality":     {"HA_Assim": "Low",    "HA_Int": "High",   "LA_Int": "High",   "LA_Sep": "Medium"},
}

QUALITATIVE_METADATA = {
    "n_interview_hours": 41.5,
    "n_journals":       286,
    "typology_n":       {"HA_Assim": 8, "HA_Int": 6, "LA_Int": 9, "LA_Sep": 5},
}

# ============================================================================
# SENSITIVITY / ROBUSTNESS BENCHMARKS
# ============================================================================
SENSITIVITY_REFERENCE = {
    "conf_020":     {"IE_lower": -0.073, "significant": True },
    "conf_030":     {"IE_lower": -0.041, "significant": True },
    "conf_040":     {"IE_lower":  0.000, "significant": False},
}

HARMAN_REFERENCE = {
    "single_factor_variance_pct": 28.7,
    "threshold_pct":              40.0,
    "cmb_free":                   True,
}

MANIP_R_REFERENCE = {"r": -0.06, "p": 0.301}

# ============================================================================
# STYLE
# ============================================================================
COLORS = {
    "condA":  "#2F4F6F",
    "condB":  "#A93226",
    "accent": "#9C6D3D",
    "gray":   "#606060",
    "light":  "#F2F2F2",
    "grid":   "#DDDDDD",
}

FIGURE_STYLE = {
    "dpi": 300,
    "figsize_default": (9, 6),
    "font_family": "DejaVu Sans",
    "title_size":   13,
    "label_size":   11,
    "tick_size":     9,
}

# ============================================================================
# TOLERANCES for empirical-vs-reference comparison
# ============================================================================
TOLERANCES = {
    "mean":       0.05,
    "sd":         0.10,
    "correlation":0.05,
    "regression": 0.03,
    "chi2":       0.15,
    "pvalue":     0.02,
    "cfi":        0.010,
    "rmsea":      0.008,
    "srmr":       0.010,
    "percentage": 2.0,
}


# ============================================================================
# BACKWARDS-COMPATIBLE ALIASES
# ----------------------------------------------------------------------------
# Analysis modules import identifiers with the "_TARGETS" suffix for legacy
# reasons. The aliases below preserve those imports while treating the values
# as reference benchmarks.
# ============================================================================
TABLE2_TARGETS         = TABLE2_REFERENCE
TABLE3_TARGETS         = TABLE3_REFERENCE
TABLE5_TARGETS         = TABLE5_REFERENCE
TABLE6_TARGETS         = TABLE6_REFERENCE
MODEL_FIT_TARGETS      = MODEL_FIT_REFERENCE
INVARIANCE_TARGETS     = INVARIANCE_REFERENCE
EFA_TARGETS            = EFA_REFERENCE
CFA_TARGETS            = CFA_REFERENCE
SENSITIVITY_TARGETS    = SENSITIVITY_REFERENCE
HARMAN_TARGETS         = HARMAN_REFERENCE
MANIP_R_TARGETS        = MANIP_R_REFERENCE


def print_config_summary():
    print("=" * 70)
    print("Reference values loaded")
    print("=" * 70)
    print(f"  N recruited = {N_RECRUITED}")
    print(f"  N final     = {N_FINAL}  (A={N_COND_A}, B={N_COND_B})")
    print(f"  Attrition   = {ATTRITION_RATE:.1%}")
    print(f"  Cohen's d for AAI slope difference = {TABLE5_REFERENCE['slope_diff']['cohen_d']}")
    print(f"  IE = {TABLE6_REFERENCE['indirect_effect']['b']}")
    print(f"  omega = {TABLE6_REFERENCE['index_moderated_mediation']['b']}")
    print("=" * 70)


if __name__ == "__main__":
    print_config_summary()
