# Analysis Pipeline

A complete, self-contained Python pipeline that estimates all quantitative and
mixed-methods results for the study of cultural framing and transparency
effects in AI-supported vocal assessment among bel canto learners.

The pipeline is organized as 14 independent modules that can be run
individually or driven by a single master script. Each module produces both
tabular output (CSV / XLSX) and, where applicable, publication-quality figures
(PNG at 300 dpi).

---

## Contents

```
.
├── README.md                         ← This file
├── requirements.txt                  ← Python dependencies
├── run_all.py                        ← Master orchestrator
├── config/
│   ├── __init__.py
│   └── reference_values.py           ← Reference values and thresholds
├── data/
│   └── dataset.xlsx                  ← Study dataset (18 sheets)
├── analysis/
│   ├── __init__.py
│   ├── _utils.py                     ← Shared data-loading utilities
│   ├── 01_attrition_consort.py       ← CONSORT participant flow
│   ├── 02_baseline_balance.py        ← Baseline demographic balance
│   ├── 03_manipulation_check.py      ← Manipulation-check test
│   ├── 04_efa_cfa_reliability.py     ← EFA + CFA + reliability
│   ├── 05_measurement_invariance.py  ← Longitudinal measurement invariance
│   ├── 06_descriptive_lgm.py         ← Descriptives + latent growth model
│   ├── 07_trajectory_plots.py        ← AAI trajectory plots
│   ├── 08_slope_distributions.py     ← Individual slope distributions
│   ├── 09_moderated_mediation.py     ← Moderated longitudinal mediation
│   ├── 10_path_diagram.py            ← Structural path diagram
│   ├── 11_simple_slopes.py           ← Simple-slopes analysis
│   ├── 12_thematic_joint_display.py  ← Mixed-methods joint display
│   ├── 13_sensitivity_analysis.py    ← Sensitivity / robustness checks
│   └── 14_common_method_bias.py      ← Harman's single-factor test
├── figures/                          ← Generated figures
├── tables/                           ← Generated tables
├── results/
│   └── summary_report.md             ← Consolidated report
└── logs/
    └── run_log.txt                   ← Run log
```

---

## Installation

```bash
pip install -r requirements.txt
```

Python 3.9 or later is required.

---

## Usage

Run the entire pipeline:

```bash
python run_all.py
```

Run a single module:

```bash
python analysis/09_moderated_mediation.py       # direct
python run_all.py --module 09                    # through the orchestrator
```

Command-line options for `run_all.py`:

| Option | Effect |
|--------|--------|
| `--module NAME` | Run only the module whose name starts with `NAME` |
| `--skip-viz` | Skip figure-only modules (07, 08, 10, 12) |
| `--quick` | Skip bootstrap-heavy computations |

---

## Data

`data/dataset.xlsx` contains 18 sheets:

| Sheet | Contents | Rows |
|-------|----------|------|
| Overview | Study description and workbook contents | — |
| Codebook | Variable definitions across all sheets | 46 |
| Institutions | Participating institution list | 27 |
| AAI_Scale_Items | Algorithmic Authority Internalization scale items | 24 |
| Berry_Identity_Items | Cross-cultural identity scale items | 16 |
| Cultural_ID_Items | Baseline cultural identification scale items | 13 |
| Manipulation_Check | Manipulation-check item bank | 8 |
| Participant_Master | Participant-level master table | 440 |
| AAI_T1_Responses | AAI item responses at T1 | 418 |
| AAI_T2_Responses | AAI item responses at T2 | 394 |
| AAI_T3_Responses | AAI item responses at T3 | 374 |
| AAI_T4_Responses | AAI item responses at T4 | 358 |
| Berry_Identity_Responses | Cross-cultural identity responses across four waves | 1,544 |
| Manipulation_Check_Responses | Post-T1 manipulation-check responses | 418 |
| Vocal_Skill_Scores | Vocal skill scores across four waves | 440 |
| Interview_Metadata | Semi-structured interview records | 41 |
| Journal_Metadata | Reflective-journal records | 286 |
| Theme_Frequencies | Coded theme frequencies by typology | 19 |

Sample: N recruited = 440; N final = 358 (Condition A: 176; Condition B: 182);
attrition = 18.6%.

---

## Pipeline outputs

### Figures (`figures/`)

| File | Description |
|------|-------------|
| `Fig07_CONSORT.png` | CONSORT-style participant flow across four waves |
| `Fig08_Trajectories.png` | Mean and individual AAI trajectories by condition |
| `Fig09_SlopeDistributions.png` | Violin + kernel-density plots of individual slopes |
| `Fig10_PathDiagram.png` | Structural moderated-mediation path diagram |
| `Fig11_SimpleSlopes.png` | Simple slopes at ±1 SD of cultural identification |
| `Fig12_JointDisplayHeatmap.png` | Joint display heatmap of theme frequencies |
| `Fig_ManipCheck.png` | Manipulation-check bar chart |

### Tables (`tables/`)

Each module writes its output tables as CSV (and, for the main summary tables,
also as XLSX).

---

## Key methods

- **Latent Growth Model (LGM).** Wave-by-wave AAI composite scores are
  modelled with fixed loadings 0, 1, 2, 3 on the linear-slope factor.

- **Moderated longitudinal mediation.** The two-stage structural model tests
  whether the AAI slope mediates the effect of assessment condition on the
  identity-strategy slope, and whether prior cultural identification moderates
  the condition effect. The indirect effect is
  $IE = \gamma_1 \cdot b$; the index of moderated mediation is
  $\omega = \gamma_3 \cdot b$. Both are tested with bias-corrected bootstrap
  confidence intervals (B = 5000).

- **Sensitivity analysis.** Robustness of the indirect effect against
  unmeasured confounding is assessed by shifting the estimate under
  hypothesized partial correlations $\rho$ of a confounder with the mediator
  and outcome.

- **Common-method bias.** Harman's single-factor test on all AAI items;
  the first-factor variance must fall below the 40% threshold for
  common-method bias to be considered non-critical.

---

## Reference values

`config/reference_values.py` holds the benchmark statistics used to check
each module's output. Values come from prior instrument-development work
by the research team, from pilot longitudinal analyses used to calibrate
the growth-model specification, and from the study-design power analysis.

The comparison utility `compare_to_reference()` in `analysis/_utils.py`
takes an estimated value and its reference benchmark and reports the
absolute difference along with a pass/fail flag based on the tolerance
in `TOLERANCES`.

---

## Dependencies

- Python ≥ 3.9
- pandas ≥ 2.0
- numpy ≥ 1.24
- scipy ≥ 1.11
- statsmodels ≥ 0.14
- semopy ≥ 2.3
- matplotlib ≥ 3.7
- seaborn ≥ 0.12
- openpyxl ≥ 3.1

The full list is in `requirements.txt`.

---

## License

MIT License. See `LICENSE` in the repository root.
